package com.example.tts.demoSpringIntro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringIntroApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringIntroApplication.class, args);
	}

}
